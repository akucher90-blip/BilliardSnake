package com.example.billiardsnake

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.content.Context
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setStatusBarColor(Color.rgb(37,21,13))
        window.setNavigationBarColor(Color.rgb(37,21,13))
        setContentView(GameView(this))
    }
}

class GameView(ctx: Context) : View(ctx) {
    private val cols = 24
    private val rows = 15
    private val snake = ArrayDeque<Point>()
    private var food = Point(12,7)
    private var dx = 1
    private var dy = 0
    private var nextDx = 1
    private var nextDy = 0
    private var score = 0
    private var running = true
    private var lastStep = 0L
    private var touchX = 0f
    private var touchY = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(System.currentTimeMillis())

    init {
        isFocusable = true
        reset()
    }

    private fun reset() {
        snake.clear()
        snake.add(Point(7,7)); snake.add(Point(6,7)); snake.add(Point(5,7)); snake.add(Point(4,7))
        dx=1; dy=0; nextDx=1; nextDy=0; score=0; running=true
        spawnFood()
        invalidate()
    }

    private fun spawnFood() {
        do {
            food = Point(rnd.nextInt(cols), rnd.nextInt(rows))
        } while (snake.any { it.x == food.x && it.y == food.y })
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w=width.toFloat()
        val top=64f
        val bottom=height-150f
        val cellW=w/cols
        val cellH=(bottom-top)/rows

        c.drawColor(Color.rgb(67,39,23))
        paint.color=Color.rgb(139,85,43)
        c.drawRoundRect(5f,top-5,w-5,bottom+5,22f,22f,paint)

        val felt=LinearGradient(0f,top,w,bottom,Color.rgb(20,112,79),Color.rgb(6,72,47),Shader.TileMode.CLAMP)
        paint.shader=felt
        c.drawRoundRect(15f,top+5,w-15,bottom-5,16f,16f,paint)
        paint.shader=null

        text.color=Color.WHITE
        text.textSize=42f
        text.typeface=Typeface.DEFAULT_BOLD
        c.drawText("Счёт: $score",18f,48f,text)

        for ((i,p) in snake.withIndex()) drawSnake(c,p,cellW,cellH,top,i==0)
        drawBall(c,food.x,food.y,cellW,cellH,(score%15)+1,top)

        drawControls(c)
        if(!running){
            paint.color=Color.argb(205,0,0,0); c.drawRect(15f,top+5,w-15,bottom-5,paint)
            text.textAlign=Paint.Align.CENTER; text.textSize=27f
            text.color=Color.WHITE; c.drawText("Столкновение!",w/2,(top+bottom)/2-10,text)
            text.textSize=17f; c.drawText("Нажмите «Новая игра»",w/2,(top+bottom)/2+24,text)
            text.textAlign=Paint.Align.LEFT
        }

        if(running && System.currentTimeMillis()-lastStep>115) { step(); lastStep=System.currentTimeMillis() }
        if(running) postInvalidateDelayed(16)
    }

    private fun drawSnake(c:Canvas,p:Point,cw:Float,ch:Float,top:Float,head:Boolean){
        val cx=(p.x+.5f)*cw; val cy=top+(p.y+.5f)*ch; val r=min(cw,ch)*.39f
        val g=RadialGradient(cx-r*.35f,cy-r*.4f,r*.05f,cx,cy,r,intArrayOf(Color.rgb(220,255,231),Color.rgb(54,194,111),Color.rgb(4,83,47)),null,Shader.TileMode.CLAMP)
        paint.shader=g; c.drawCircle(cx,cy,r,paint); paint.shader=null
        if(head){
            paint.color=Color.BLACK
            c.drawCircle(cx-r*.27f,cy-r*.13f,r*.055f,paint); c.drawCircle(cx+r*.27f,cy-r*.13f,r*.055f,paint)
        }
    }

    private fun drawBall(c:Canvas,gx:Int,gy:Int,cw:Float,ch:Float,n:Int,top:Float){
        val cx=(gx+.5f)*cw; val cy=top+(gy+.5f)*ch; val r=min(cw,ch)*.38f
        val shadow=Paint(Paint.ANTI_ALIAS_FLAG); shadow.color=Color.argb(75,0,0,0); c.drawCircle(cx+2,cy+3,r,shadow)
        val base=when(n){
            1,9->Color.rgb(245,190,35); 2,10->Color.rgb(35,80,190); 3,11->Color.rgb(205,35,38)
            4,12->Color.rgb(125,55,160); 5,13->Color.rgb(235,90,30); 6,14->Color.rgb(35,145,75)
            7,15->Color.rgb(110,45,25); else->Color.BLACK
        }
        val colors=if(n==8) intArrayOf(Color.WHITE,Color.rgb(40,40,40),Color.BLACK) else intArrayOf(Color.WHITE,base,Color.rgb(40,40,40))
        val g=RadialGradient(cx-r*.35f,cy-r*.45f,r*.05f,cx,cy,r,colors,floatArrayOf(0f,.28f,1f),Shader.TileMode.CLAMP)
        paint.shader=g;c.drawCircle(cx,cy,r,paint);paint.shader=null
        // white number plate for maximum readability
        paint.color=Color.WHITE;c.drawCircle(cx,cy,r*.39f,paint)
        text.textAlign=Paint.Align.CENTER;text.textBaseline=Paint.FontMetricsInt().let { Paint.Align.CENTER }
        text.color=Color.BLACK;text.typeface=Typeface.DEFAULT_BOLD;text.textSize=r*.72f
        c.drawText(n.toString(),cx,cy-r*.24f,text)
        text.textAlign=Paint.Align.LEFT
    }

    private fun drawControls(c:Canvas){
        val y=height-105f; val cx=width/2f; val s=58f; val gap=8f
        button(c,cx,y-s-gap,"▲"); button(c,cx-s-gap,y,"◀"); button(c,cx,y,"▼"); button(c,cx+s+gap,y,"▶")
        button(c,cx,y+68,"Новая игра",true)
    }
    private fun button(c:Canvas,x:Float,y:Float,label:String,wide:Boolean=false){
        paint.color=Color.rgb(35,35,35); val ww=if(wide)150f else 58f; val hh=if(wide)48f else 58f
        c.drawRoundRect(x-ww/2,y-hh/2,x+ww/2,y+hh/2,14f,14f,paint)
        text.color=Color.WHITE;text.textAlign=Paint.Align.CENTER;text.textSize=if(wide)16f else 25f;text.typeface=Typeface.DEFAULT_BOLD
        c.drawText(label,x,y+text.textSize*.34f,text);text.textAlign=Paint.Align.LEFT
    }

    private fun step(){
        if(!running)return
        dx=nextDx;dy=nextDy
        val h=Point(snake.first().x+dx,snake.first().y+dy)
        if(h.x<0||h.x>=cols||h.y<0||h.y>=rows||snake.any{it.x==h.x&&it.y==h.y}){running=false;return}
        snake.addFirst(h)
        if(h.x==food.x&&h.y==food.y){score++;spawnFood()}else snake.removeLast()
    }

    private fun setDir(nx:Int,ny:Int){
        if(nx==-dx&&ny==-dy)return
        nextDx=nx;nextDy=ny
        if(!running)reset()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN->{touchX=e.x;touchY=e.y;return true}
            MotionEvent.ACTION_UP->{
                val ex=e.x;val ey=e.y;val ax=abs(ex-touchX);val ay=abs(ey-touchY)
                if(ax>35||ay>35){if(ax>ay)setDir(if(ex>touchX)1 else -1,0) else setDir(0,if(ey>touchY)1 else -1)}
                else {
                    val cy=height-105f; val cx=width/2f
                    if(ey>cy-30&&ey<cy+30){ if(ex<cx-65)setDir(-1,0) else if(ex>cx+65)setDir(1,0) else setDir(0,1)}
                    else if(ey<cy-35&&ey>cy-100&&abs(ex-cx)<45)setDir(0,-1)
                    else if(ey>height-145&&ey<height-80&&abs(ex-cx)<85)reset()
                }
                return true
            }
        }
        return true
    }
}
