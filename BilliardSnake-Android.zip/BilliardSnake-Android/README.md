# Бильярдная змейка

Android-проект игры «Змейка», где змейка съедает пронумерованные бильярдные шары.

## Сборка APK
1. Откройте папку `BilliardSnake` в Android Studio.
2. Дождитесь синхронизации Gradle.
3. Выберите `Build → Build APK(s)`.
4. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Минимальная версия Android: 6.0 (API 23).
